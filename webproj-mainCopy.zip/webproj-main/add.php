<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli("localhost", "root", "root", "recipedb", 8889);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}





//_____ Retrieve categories from database___________-


$categoriesQuery = "SELECT id, categoryname FROM recipecategory ORDER BY id";
$categoriesResult = $conn->query($categoriesQuery);
$categories = [];
if ($categoriesResult->num_rows > 0) {
    while($row = $categoriesResult->fetch_assoc()) {
        $categories[] = $row;
    }
}







$userID = $_SESSION['userID'] ?? 2;

$successMessage = '';
$errorMessage = '';

function getRandomDigits() {
    return rand(1000, 9999);
}

function cleanFileName($name) {
    $clean = preg_replace('/[^a-zA-Z0-9]/', '_', $name);
    $clean = substr($clean, 0, 20);
    return $clean;
}

function getUploadPath($type) {
    if ($type === 'image') {
        $dir = 'uploads/images/';
    } elseif ($type === 'video') {
        $dir = 'uploads/videos/';
    } else {
        $dir = 'uploads/';
    }
    if (!is_dir($dir)) {
        mkdir($dir, 0777, true);
    }
    return $dir;
}







// ___________When form is submitted__________________--

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addRecipe'])) {
    
    if (!isset($_FILES['photoFileName']) || $_FILES['photoFileName']['error'] === UPLOAD_ERR_NO_FILE) {
        $errorMessage = "❌ Please upload a recipe image! The picture is required. 📸";
    } else {
        
        $name = $conn->real_escape_string($_POST['name']);
        $categoryID = (int)$_POST['categoryID'];
        $description = $conn->real_escape_string($_POST['description']);
        
        $photoFileName = "";
        $videoFilePath = "";
        $photoError = false;
        
        
        
        
        
        
        
        
        
        
        
        //____________________ Upload recipe image____________________
        
        if ($_FILES['photoFileName']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = getUploadPath('image');
            $fileTmpPath = $_FILES['photoFileName']['tmp_name'];
            $originalName = $_FILES['photoFileName']['name'];
            $fileExtension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $maxFileSize = 5 * 1024 * 1024;
            
            
            
            
            
            
            
            
            
            
            
            //______________________ Validate image size and format________________
            
            if ($_FILES['photoFileName']['size'] > $maxFileSize) {
                $errorMessage = "❌ Image file is too large! Maximum size is 5MB.";
                $photoError = true;
            }
            elseif (!in_array($fileExtension, $allowedExtensions)) {
                $errorMessage = "❌ Invalid image format! Please use JPG, PNG, GIF, or WebP.";
                $photoError = true;
            }
            else {
                $cleanName = cleanFileName($name);
                $randomDigits = getRandomDigits();
                $newFileName = $cleanName . '_' . $randomDigits . '.' . $fileExtension;
                $destPath = $uploadDir . $newFileName;
                
                if (move_uploaded_file($fileTmpPath, $destPath)) {
                    $photoFileName = $destPath;
                } else {
                    $errorMessage = "❌ Failed to upload image. Please try again!";
                    $photoError = true;
                }
            }
        }
        
        if (!$photoError && empty($errorMessage)) {
            
            if (isset($_POST['videoOption'])) {
                
                
                
                
                
                
                
                
                //_____________ Save video URL if provided____________________
                
                
                if ($_POST['videoOption'] === 'url' && !empty($_POST['videoUrl'])) {
                    $originalVideoUrl = $_POST['videoUrl'];
                    if (strpos($originalVideoUrl, '?') !== false) {
                        $videoFilePath = $originalVideoUrl . '&temp_id=' . time();
                    } else {
                        $videoFilePath = $originalVideoUrl . '?temp_id=' . time();
                    }
                } 
                
                
                
                
                
                
                
                
                // ____________________Upload video file if selected________________
                
                elseif ($_POST['videoOption'] === 'upload' && isset($_FILES['videoFile']) && $_FILES['videoFile']['error'] === UPLOAD_ERR_OK) {
                    $uploadDir = getUploadPath('video');
                    $fileTmpPath = $_FILES['videoFile']['tmp_name'];
                    $originalName = $_FILES['videoFile']['name'];
                    $fileExtension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
                    $allowedVideoExtensions = ['mp4', 'avi', 'mov', 'mpeg', 'webm'];
                    $maxVideoSize = 50 * 1024 * 1024;
                    
                    if ($_FILES['videoFile']['size'] > $maxVideoSize) {
                        $errorMessage = "❌ Video file is too large! Maximum size is 50MB.";
                    }
                    elseif (!in_array($fileExtension, $allowedVideoExtensions)) {
                        $errorMessage = "❌ Invalid video format! Please use MP4, AVI, MOV, MPEG, or WebM.";
                    }
                    else {
                        $cleanName = cleanFileName($name);
                        $randomDigits = getRandomDigits();
                        $newFileName = $cleanName . '_video_' . $randomDigits . '.' . $fileExtension;
                        $destPath = $uploadDir . $newFileName;
                        
                        if (move_uploaded_file($fileTmpPath, $destPath)) {
                            $videoFilePath = $destPath;
                        } else {
                            $errorMessage = "❌ Failed to upload video. Please try again!";
                        }
                    }
                }
            }
        }
        
        if (!$photoError && empty($errorMessage)) {
            
            
            
            
            
            
            
            //_______________- Insert new recipe into database_______________-
            
            $insertRecipeQuery = "INSERT INTO recipe (userID, categoryID, name, description, photoFileName, videoFilePath) 
                                  VALUES ($userID, $categoryID, '$name', '$description', '$photoFileName', '$videoFilePath')";
            
            if ($conn->query($insertRecipeQuery) === TRUE) {
                $recipeID = $conn->insert_id;
                
                if (isset($_POST['videoOption']) && $_POST['videoOption'] === 'url' && !empty($_POST['videoUrl'])) {
                    $originalVideoUrl = $_POST['videoUrl'];
                    if (strpos($originalVideoUrl, '?') !== false) {
                        $finalVideoUrl = $originalVideoUrl . '&recipe_id=' . $recipeID;
                    } else {
                        $finalVideoUrl = $originalVideoUrl . '?recipe_id=' . $recipeID;
                    }
                    $conn->query("UPDATE recipe SET videoFilePath = '$finalVideoUrl' WHERE id = $recipeID");
                }
                
                if (!empty($_POST['ingredientName'])) {
                    
                    
                    
                    
                    
                    
                    // ________________Insert ingredients for the recipe___________________
                    
                    $stmt = $conn->prepare("INSERT INTO ingredients (recipeID, ingredientName, ingredientQuantity) VALUES (?, ?, ?)");
                    
                    foreach ($_POST['ingredientName'] as $i => $ingredientName) {
                        if (!empty($ingredientName) && !empty($_POST['ingredientQuantity'][$i])) {
                            $ingredientQuantity = $_POST['ingredientQuantity'][$i];
                            $stmt->bind_param("iss", $recipeID, $ingredientName, $ingredientQuantity);
                            $stmt->execute();
                        }
                    }
                    $stmt->close();
                }
                
                if (!empty($_POST['stepDescription'])) {
                    
                    
                    
                    
                    
                    
                    //_____________ Insert instructions (steps) for the recipe_________
                    
                    
                    $stmt = $conn->prepare("INSERT INTO instructions (recipeID, step, stepOrder) VALUES (?, ?, ?)");
                    
                    foreach ($_POST['stepDescription'] as $i => $stepDescription) {
                        if (!empty($stepDescription)) {
                            $stepOrder = $i + 1;
                            $stepTitle = !empty($_POST['stepTitle'][$i]) ? $_POST['stepTitle'][$i] . ': ' : '';
                            $fullStep = $stepTitle . $stepDescription;
                            $stmt->bind_param("isi", $recipeID, $fullStep, $stepOrder);
                            $stmt->execute();
                        }
                    }
                    $stmt->close();
                }
                
                $successMessage = "✅ Recipe '$name' has been saved successfully! 🎉";
                
                echo "<script>
                        setTimeout(function() {
                        














            // ______________________Redirect to my recipes page after adding_________________

                            window.location.href = 'myrecipes.php';
                        }, 2000);
                      </script>";
            } else {
                $errorMessage = "❌ Database error: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Kids Recipe - Little Chefs</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&family=Comic+Neue:wght@700&display=swap" rel="stylesheet">
  <style>
    :root {
      --primary: #FF9AA2;
      --secondary: #FFDAC1;
      --mint: #B5EAD7;
      --lavender: #C7CEEA;
      --yellow: #FFE5B4;
      --dark: #5D576B;
      --white: #ffffff;
      --border-radius: 16px;
      --box-shadow: 0 8px 25px rgba(93, 87, 107, 0.1);
      --transition: all 0.3s ease;
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html, body {
      height: 100%;
    }

    body {
      margin: 0;
      padding: 0;
      font-family: 'Nunito', sans-serif;
      background: linear-gradient(135deg, var(--secondary), var(--lavender));
      color: var(--dark);
      line-height: 1.6;
    }

    .container {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      background: linear-gradient(to right, var(--primary), var(--lavender));
      padding: 15px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin: 0;
    }

    .header-left {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .logo {
      width: 130px;
      height: auto;
      filter: drop-shadow(0 4px 6px rgba(0,0,0,0.15));
    }

    header h1 {
      font-family: 'Comic Neue', cursive;
      font-size: 2.4rem;
      color: white;
    }

    nav a {
      margin-left: 25px;
      color: white;
      text-decoration: none;
      font-weight: 700;
      cursor: pointer;
      padding-bottom: 5px;
      position: relative;
    }

    nav a:hover {
      color: var(--yellow);
    }

    nav a.active {
      color: var(--yellow);
      border-bottom: 3px solid var(--yellow);
    }

    .main-wrapper {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 40px 20px;
    }

    .page-header {
      width: 100%;
      max-width: 1000px;
      margin-bottom: 30px;
      text-align: center;
    }

    .page-header h2 {
      font-family: 'Comic Neue', cursive;
      font-size: 2.8rem;
      color: var(--dark);
      margin-bottom: 10px;
      text-shadow: 2px 2px 0 var(--yellow);
    }

    .page-header p {
      font-size: 1.3rem;
      background: white;
      padding: 15px 30px;
      border-radius: 50px;
      display: inline-block;
      border: 4px solid var(--mint);
      box-shadow: var(--box-shadow);
    }

    .recipe-container {
      max-width: 1000px;
      width: 100%;
      background-color: white;
      border-radius: var(--border-radius);
      box-shadow: var(--box-shadow);
      overflow: hidden;
      border: 6px solid var(--mint);
    }

    .success-message {
      background-color: rgba(181, 234, 215, 0.3);
      color: var(--dark);
      padding: 25px;
      border-radius: 14px;
      margin-bottom: 30px;
      display: none;
      align-items: center;
      border: 3px solid var(--mint);
      animation: slideIn 0.5s ease-out;
    }

    .error-message {
      background-color: rgba(255, 154, 162, 0.2);
      color: var(--dark);
      padding: 25px;
      border-radius: 14px;
      margin-bottom: 30px;
      display: flex;
      align-items: center;
      border: 3px solid var(--primary);
      animation: slideIn 0.5s ease-out;
    }

    @keyframes slideIn {
      from { opacity: 0; transform: translateX(-20px); }
      to { opacity: 1; transform: translateX(0); }
    }

    .success-message i, .error-message i {
      margin-right: 15px;
      font-size: 2rem;
    }

    .success-message i {
      color: var(--mint);
    }

    .error-message i {
      color: var(--primary);
    }

    .success-message span, .error-message span {
      font-family: 'Comic Neue', cursive;
      font-size: 1.3rem;
      font-weight: 700;
    }

    .recipe-form {
      padding: 40px;
      background-color: #FFF9F5;
    }

    .form-section {
      margin-bottom: 35px;
      padding: 25px;
      border-radius: 14px;
      background-color: white;
      border-left: 6px solid var(--mint);
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
      transition: var(--transition);
    }

    .form-section:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
      border-left-color: var(--primary);
    }

    .section-title {
      font-family: 'Comic Neue', cursive;
      font-size: 1.8rem;
      color: var(--dark);
      margin-bottom: 20px;
      display: flex;
      align-items: center;
    }

    .section-title i {
      margin-right: 12px;
      color: var(--primary);
      font-size: 1.5rem;
      background: var(--yellow);
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: var(--dark);
      font-size: 1.05rem;
    }

    .required {
      color: var(--primary);
    }

    input[type="text"],
    input[type="url"],
    textarea,
    select {
      width: 100%;
      padding: 15px 18px;
      border: 2px solid var(--secondary);
      border-radius: 10px;
      font-size: 1rem;
      font-family: 'Nunito', sans-serif;
      transition: var(--transition);
      background-color: #FFFEFC;
    }

    input[type="text"]:focus,
    input[type="url"]:focus,
    textarea:focus,
    select:focus {
      border-color: var(--primary);
      box-shadow: 0 0 0 3px rgba(255, 154, 162, 0.2);
      outline: none;
    }

    textarea {
      min-height: 120px;
      resize: vertical;
    }

    select {
      appearance: none;
      background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%235D576B' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
      background-repeat: no-repeat;
      background-position: right 18px center;
      background-size: 16px;
      padding-right: 50px;
    }

    .ingredient-row,
    .step-row {
      display: flex;
      gap: 15px;
      margin-bottom: 15px;
      align-items: flex-start;
    }

    .ingredient-name,
    .step-number {
      flex: 2;
    }

    .ingredient-amount {
      flex: 1;
    }

    .step-content {
      flex: 3;
    }

    .add-btn,
    .remove-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 12px 24px;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      font-weight: 600;
      transition: var(--transition);
      font-size: 1rem;
      font-family: 'Comic Neue', cursive;
    }

    .add-btn {
      background-color: var(--mint);
      color: var(--dark);
      margin-top: 10px;
      box-shadow: 0 4px 0 #8FD5B7;
    }

    .add-btn:hover {
      background-color: #9CDBC4;
      transform: translateY(-3px);
      box-shadow: 0 6px 0 #8FD5B7;
    }

    .remove-btn {
      background-color: var(--primary);
      color: white;
      padding: 10px 18px;
      box-shadow: 0 4px 0 #E88A92;
    }

    .remove-btn:hover {
      background-color: #FF8A94;
      transform: translateY(-2px);
    }

    .step-controls {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 70px;
      padding-top: 28px;
    }

    .upload-area {
      border: 3px dashed var(--secondary);
      border-radius: 14px;
      padding: 35px 25px;
      text-align: center;
      cursor: pointer;
      transition: var(--transition);
      background-color: #FFFCF9;
    }

    .upload-area.required-missing {
      border-color: var(--primary);
      background-color: rgba(255, 154, 162, 0.2);
      animation: shake 0.5s ease-in-out;
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-10px); }
      75% { transform: translateX(10px); }
    }

    .upload-area:hover {
      border-color: var(--primary);
      background-color: rgba(255, 154, 162, 0.05);
      transform: translateY(-5px);
    }

    .upload-area.dragover {
      border-color: var(--mint);
      background-color: rgba(181, 234, 215, 0.1);
    }

    .upload-area i {
      font-size: 3rem;
      color: var(--primary);
      margin-bottom: 15px;
    }

    .upload-area p {
      color: var(--dark);
      margin-bottom: 8px;
      font-weight: 500;
    }

    .upload-area span {
      font-size: 0.9rem;
      color: #888;
    }

    #file-name {
      margin-top: 15px;
      font-size: 0.95rem;
      color: var(--dark);
      padding: 10px 18px;
      background-color: rgba(181, 234, 215, 0.2);
      border-radius: 8px;
      display: inline-flex;
      align-items: center;
    }

    #file-name i {
      margin-right: 10px;
      color: var(--mint);
    }

    .video-options {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
      gap: 15px;
      margin-bottom: 20px;
    }

    .video-option {
      position: relative;
    }

    .video-option input[type="radio"] {
      position: absolute;
      opacity: 0;
      width: 0;
      height: 0;
    }

    .video-option label {
      display: block;
      padding: 18px;
      background-color: #FFFCF9;
      border-radius: 12px;
      text-align: center;
      cursor: pointer;
      transition: var(--transition);
      border: 2px solid var(--secondary);
      font-weight: 500;
    }

    .video-option input[type="radio"]:checked + label {
      border-color: var(--primary);
      background-color: rgba(255, 154, 162, 0.1);
      color: var(--primary);
      box-shadow: 0 4px 0 var(--primary);
    }

    .video-option label:hover {
      transform: translateY(-3px);
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    }

    .video-input {
      display: none;
      margin-top: 20px;
      animation: slideDown 0.4s ease-out;
    }

    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .video-input.active {
      display: block;
    }

    .form-actions {
      display: flex;
      justify-content: center;
      gap: 20px;
      margin-top: 40px;
      padding-top: 30px;
      border-top: 3px dashed var(--secondary);
    }

    .submit-btn,
    .reset-btn,
    .cancel-btn {
      padding: 18px 40px;
      font-size: 1.2rem;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      font-weight: 700;
      transition: var(--transition);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 180px;
      font-family: 'Comic Neue', cursive;
    }

    .submit-btn {
      background: linear-gradient(to right, var(--primary), var(--lavender));
      color: white;
      box-shadow: 0 6px 0 var(--dark);
    }

    .submit-btn:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 0 var(--dark);
    }

    .reset-btn {
      background-color: var(--yellow);
      color: var(--dark);
      border: 3px solid var(--secondary);
      box-shadow: 0 6px 0 var(--secondary);
    }

    .reset-btn:hover {
      background-color: #FFDFB0;
      transform: translateY(-3px);
      box-shadow: 0 8px 0 var(--secondary);
    }

    .cancel-btn {
      background-color: #E0E0E0;
      color: var(--dark);
      border: 3px solid #CCCCCC;
      box-shadow: 0 6px 0 #CCCCCC;
    }

    .cancel-btn:hover {
      background-color: #D6D6D6;
      transform: translateY(-3px);
      box-shadow: 0 8px 0 #CCCCCC;
    }

    .counter {
      font-size: 0.85rem;
      color: #888;
      text-align: right;
      margin-top: 8px;
    }

    footer {
      background: var(--mint);
      padding: 25px;
      text-align: center;
      font-weight: 600;
    }

    @media (max-width: 768px) {
      header {
        flex-direction: column;
        gap: 15px;
      }

      .logo {
        width: 110px;
      }

      .ingredient-row,
      .step-row {
        flex-direction: column;
        gap: 15px;
      }

      .step-controls {
        width: 100%;
        justify-content: flex-start;
        padding-top: 0;
      }

      .form-actions {
        flex-direction: column;
      }

      .page-header h2 {
        font-size: 2.2rem;
      }

      .page-header p {
        font-size: 1.1rem;
        padding: 12px 20px;
      }
    }
  </style>
</head>
<body>

<div class="container">

  <header>
    <div class="header-left">
      <img src="photo.png" alt="Kids Recipes Logo" class="logo">
      <h1>LittleChefs</h1>
    </div>

    <nav>
      <a href="index.php">Home</a>
      <a href="#">Users</a>
      <a href="#">Admins</a>
    </nav>
  </header>

  <div class="main-wrapper">

    <div class="page-header">
      <h2><i class="fas fa-birthday-cake"></i> Add Kids Recipe</h2>
      <p>Create fun and healthy recipes for little chefs! 🧒🍕🥦</p>
    </div>

    <div class="recipe-container">
      
      <?php if ($successMessage): ?>
      <div class="success-message" style="display: flex;">
        <i class="fas fa-check-circle"></i>
        <span><?php echo $successMessage; ?><br><small>Redirecting to your recipes...</small></span>
      </div>
      <?php endif; ?>
      
      <?php if ($errorMessage): ?>
      <div class="error-message" style="display: flex;">
        <i class="fas fa-exclamation-triangle"></i>
        <span><?php echo $errorMessage; ?></span>
      </div>
      <?php endif; ?>

      <form class="recipe-form" id="recipeForm" method="POST" enctype="multipart/form-data" action="" style="<?php echo $successMessage ? 'display: none;' : 'display: block;'; ?>">
        
        <!-- Section 1: Basic Information -->
        <div class="form-section">
          <h2 class="section-title"><i class="fas fa-info-circle"></i> Recipe Info</h2>

          <div class="form-group">
            <label for="name">Recipe Name <span class="required">*</span></label>
            <input type="text" id="name" name="name" placeholder="e.g., Rainbow Fruit Skewers 🍓🌈" required>
            <div class="counter"><span id="nameCount">0</span>/50 characters</div>
          </div>

          <div class="form-group">
            <label for="categoryID">Recipe Category <span class="required">*</span></label>
            
            
            
            
            
            
            
            
            
            
            
            <!-- ***********Display categories in dropdown menu******************8-->
            
            
            <select id="categoryID" name="categoryID" required>
              <option value="">Select a category</option>
              <?php foreach ($categories as $category): ?>
                <option value="<?php echo $category['id']; ?>">
                  <?php echo htmlspecialchars($category['categoryname']); ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>

          <div class="form-group">
            <label for="description">Recipe Description <span class="required">*</span></label>
            <textarea id="description" name="description" placeholder="Describe your recipe in a fun way! Kids will love it! 🎨✨" required></textarea>
            <div class="counter"><span id="descCount">0</span>/200 characters</div>
          </div>
        </div>

        <!-- Section 2: Recipe Image -->
        <div class="form-section">
          <h2 class="section-title"><i class="fas fa-camera"></i> Recipe Picture</h2>

          <div class="form-group">
            <label>Upload Recipe Image <span class="required">*</span></label>
            <div class="upload-area" id="uploadArea">
              <i class="fas fa-cloud-upload-alt"></i>
              <p>Drag & drop or click to upload a fun picture! 📸</p>
              <span>Max size: 5MB (JPG, PNG, GIF, WebP)</span>
            </div>
            <input type="file" id="photoFileName" name="photoFileName" accept="image/*" style="display: none;" required>
            <div id="file-name"></div>
          </div>
        </div>

        <!-- Section 3: Ingredients -->
        <div class="form-section">
          <h2 class="section-title"><i class="fas fa-list-ul"></i> Ingredients</h2>

          <div id="ingredientsContainer">
            <div class="ingredient-row">
              <div class="form-group ingredient-name">
                <label>Ingredient Name <span class="required">*</span></label>
                <input type="text" name="ingredientName[]" placeholder="e.g., Banana 🍌" required>
              </div>
              <div class="form-group ingredient-amount">
                <label>Amount <span class="required">*</span></label>
                <input type="text" name="ingredientQuantity[]" placeholder="e.g., 1 medium" required>
              </div>
            </div>
          </div>

          <button type="button" class="add-btn" id="addIngredient">
            <i class="fas fa-plus"></i> Add More Ingredients
          </button>
        </div>

        <!-- Section 4: Preparation Steps -->
        <div class="form-section">
          <h2 class="section-title"><i class="fas fa-list-ol"></i> Instructions</h2>

          <div id="stepsContainer">
            <div class="step-row">
              <div class="form-group step-number">
                <label>Step #<span class="step-counter">1</span></label>
                <input type="text" name="stepTitle[]" placeholder="Step title (optional)">
              </div>
              <div class="form-group step-content">
                <label>Step Description <span class="required">*</span></label>
                <textarea name="stepDescription[]" placeholder="Write step in a fun way for kids! 🎯" rows="2" required></textarea>
              </div>
              <div class="step-controls">
                <button type="button" class="remove-btn remove-step" style="display: none;">
                  <i class="fas fa-trash"></i> Remove
                </button>
              </div>
            </div>
          </div>

          <button type="button" class="add-btn" id="addStep">
            <i class="fas fa-plus"></i> Add Another Step
          </button>
        </div>

        <!-- Section 5: Video (Optional) -->
        <div class="form-section">
          <h2 class="section-title"><i class="fas fa-video"></i> Recipe Video (Optional)</h2>

          <div class="video-options">
            <div class="video-option">
              <input type="radio" id="videoNone" name="videoOption" value="none" checked>
              <label for="videoNone"><i class="fas fa-times-circle"></i> No Video</label>
            </div>
            <div class="video-option">
              <input type="radio" id="videoURL" name="videoOption" value="url">
              <label for="videoURL"><i class="fas fa-link"></i> Video Link</label>
            </div>
            <div class="video-option">
              <input type="radio" id="videoUpload" name="videoOption" value="upload">
              <label for="videoUpload"><i class="fas fa-upload"></i> Upload Video</label>
            </div>
          </div>

          <div class="video-input" id="urlInput">
            <div class="form-group">
              <label for="videoUrl">Video URL</label>
              <input type="url" id="videoUrl" name="videoUrl" placeholder="https://www.youtube.com/watch?v=...">
            </div>
          </div>

          <div class="video-input" id="uploadInput">
            <div class="form-group">
              <label for="videoFile">Video File</label>
              <input type="file" id="videoFile" name="videoFile" accept="video/*">
              <div class="counter">Max size: 50MB (MP4, AVI, MOV, MPEG, WebM)</div>
            </div>
          </div>
        </div>

        <!-- Form Actions -->
        <div class="form-actions">
          <button type="submit" name="addRecipe" class="submit-btn">
            <i class="fas fa-save"></i> Save Recipe
          </button>
          <button type="reset" class="reset-btn" id="resetBtn">
            <i class="fas fa-redo"></i> Start Over
          </button>
          <button type="button" class="cancel-btn" id="cancelBtn">
            <i class="fas fa-times"></i> Cancel
          </button>
        </div>
      </form>
    </div>
  </div>

  <footer>
    © 2026 Kids Recipes — Made with 💖 for little ones
  </footer>

</div>

<script>
  // Main elements
  const recipeForm = document.getElementById('recipeForm');
  const ingredientsContainer = document.getElementById('ingredientsContainer');
  const stepsContainer = document.getElementById('stepsContainer');
  const addIngredientBtn = document.getElementById('addIngredient');
  const addStepBtn = document.getElementById('addStep');
  const uploadArea = document.getElementById('uploadArea');
  const recipeImage = document.getElementById('photoFileName');
  const fileNameDisplay = document.getElementById('file-name');

  // Character counters
  const nameCount = document.getElementById('nameCount');
  const descCount = document.getElementById('descCount');
  const recipeNameInput = document.getElementById('name');
  const recipeDescInput = document.getElementById('description');

  // Video options
  const videoOptions = document.querySelectorAll('input[name="videoOption"]');
  const urlInput = document.getElementById('urlInput');
  const uploadInput = document.getElementById('uploadInput');

  // Character counter for recipe name
  recipeNameInput.addEventListener('input', function() {
    nameCount.textContent = this.value.length;
    nameCount.style.color = this.value.length > 50 ? '#FF9AA2' : '#B5EAD7';
  });

  // Character counter for recipe description
  recipeDescInput.addEventListener('input', function() {
    descCount.textContent = this.value.length;
    descCount.style.color = this.value.length > 200 ? '#FF9AA2' : '#B5EAD7';
  });

  // Recipe image upload with drag & drop
  uploadArea.addEventListener('click', function() {
    recipeImage.click();
  });

  recipeImage.addEventListener('change', function() {
    if (this.files.length > 0) {
      const fileName = this.files[0].name;
      fileNameDisplay.innerHTML = `<i class="fas fa-check-circle"></i> Selected: <strong>${fileName}</strong>`;
      uploadArea.style.borderColor = '#B5EAD7';
      uploadArea.style.backgroundColor = 'rgba(181, 234, 215, 0.1)';
      uploadArea.classList.remove('required-missing');
      
      // Remove any existing error message
      const existingError = document.querySelector('.client-error-message');
      if (existingError) {
        existingError.remove();
      }
    } else {
      fileNameDisplay.textContent = '';
      uploadArea.style.borderColor = '#FFDAC1';
      uploadArea.style.backgroundColor = '#FFFCF9';
    }
  });

  // Drag and drop functionality
  uploadArea.addEventListener('dragover', function(e) {
    e.preventDefault();
    this.classList.add('dragover');
  });

  uploadArea.addEventListener('dragleave', function() {
    this.classList.remove('dragover');
  });

  uploadArea.addEventListener('drop', function(e) {
    e.preventDefault();
    this.classList.remove('dragover');

    if (e.dataTransfer.files.length) {
      recipeImage.files = e.dataTransfer.files;
      const fileName = e.dataTransfer.files[0].name;
      fileNameDisplay.innerHTML = `<i class="fas fa-check-circle"></i> Selected: <strong>${fileName}</strong>`;
      uploadArea.style.borderColor = '#B5EAD7';
      uploadArea.style.backgroundColor = 'rgba(181, 234, 215, 0.1)';
      uploadArea.classList.remove('required-missing');
      
      // Remove any existing error message
      const existingError = document.querySelector('.client-error-message');
      if (existingError) {
        existingError.remove();
      }
    }
  });

  // Function to show error message
  function showImageError() {
    // Remove any existing error message
    const existingError = document.querySelector('.client-error-message');
    if (existingError) {
      existingError.remove();
    }
    
    // Create new error message
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message client-error-message';
    errorDiv.style.display = 'flex';
    errorDiv.style.margin = '20px';
    errorDiv.innerHTML = `
      <i class="fas fa-exclamation-triangle"></i>
      <span>❌ Please upload a recipe image! The picture is required. 📸</span>
    `;
    
    // Insert error message before the form
    const recipeContainer = document.querySelector('.recipe-container');
    recipeContainer.insertBefore(errorDiv, recipeForm);
    
    // Add shake effect to upload area
    uploadArea.classList.add('required-missing');
    uploadArea.style.borderColor = '#FF9AA2';
    
    // Scroll to upload area
    uploadArea.scrollIntoView({ behavior: 'smooth', block: 'center' });
    
    // Auto remove error after 4 seconds
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
      uploadArea.classList.remove('required-missing');
    }, 4000);
  }

  // Client-side validation for image before submit
  recipeForm.addEventListener('submit', function(e) {
    // Check if image is selected
    if (!recipeImage.files || recipeImage.files.length === 0) {
      e.preventDefault();
      showImageError();
      return false;
    }
  });

  // Add new ingredient
  let ingredientCount = 1;

  addIngredientBtn.addEventListener('click', function() {
    ingredientCount++;

    const newIngredientRow = document.createElement('div');
    newIngredientRow.className = 'ingredient-row';
    newIngredientRow.innerHTML = `
      <div class="form-group ingredient-name">
        <label>Ingredient Name <span class="required">*</span></label>
        <input type="text" name="ingredientName[]" placeholder="e.g., Cheese 🧀" required>
      </div>
      <div class="form-group ingredient-amount">
        <label>Amount <span class="required">*</span></label>
        <input type="text" name="ingredientQuantity[]" placeholder="e.g., 2 slices" required>
      </div>
      <div class="step-controls">
        <button type="button" class="remove-btn remove-ingredient">
          <i class="fas fa-trash"></i> Remove
        </button>
      </div>
    `;

    ingredientsContainer.appendChild(newIngredientRow);

    const removeBtn = newIngredientRow.querySelector('.remove-ingredient');
    removeBtn.addEventListener('click', function() {
      ingredientsContainer.removeChild(newIngredientRow);
      ingredientCount--;
    });
  });

  // Add new step
  let stepCount = 1;

  addStepBtn.addEventListener('click', function() {
    stepCount++;

    const newStepRow = document.createElement('div');
    newStepRow.className = 'step-row';
    newStepRow.innerHTML = `
      <div class="form-group step-number">
        <label>Step #<span class="step-counter">${stepCount}</span></label>
        <input type="text" name="stepTitle[]" placeholder="Step title (optional)">
      </div>
      <div class="form-group step-content">
        <label>Step Description <span class="required">*</span></label>
        <textarea name="stepDescription[]" placeholder="Write step in a fun way for kids! 🎯" rows="2" required></textarea>
      </div>
      <div class="step-controls">
        <button type="button" class="remove-btn remove-step">
          <i class="fas fa-trash"></i> Remove
        </button>
      </div>
    `;

    stepsContainer.appendChild(newStepRow);

    const removeBtn = newStepRow.querySelector('.remove-step');
    removeBtn.addEventListener('click', function() {
      stepsContainer.removeChild(newStepRow);
      stepCount--;
      updateStepNumbers();
    });

    if (stepCount > 1) {
      document.querySelectorAll('.remove-step')[0].style.display = 'block';
    }
  });

  // Update step numbers
  function updateStepNumbers() {
    const stepCounters = document.querySelectorAll('.step-counter');
    stepCounters.forEach((counter, index) => {
      counter.textContent = index + 1;
    });

    if (stepCount === 1) {
      document.querySelectorAll('.remove-step')[0].style.display = 'none';
    }
  }

  // Show/hide video fields based on selection
  videoOptions.forEach(option => {
    option.addEventListener('change', function() {
      urlInput.classList.remove('active');
      uploadInput.classList.remove('active');

      if (this.value === 'url') {
        urlInput.classList.add('active');
      } else if (this.value === 'upload') {
        uploadInput.classList.add('active');
      }
    });
  });

  // Cancel button
  document.getElementById('cancelBtn').addEventListener('click', function() {
    window.location.href = 'myrecipes.php';
  });

  // Form reset
  document.getElementById('resetBtn').addEventListener('click', function(e) {
    e.preventDefault();

    if (confirm('Are you sure you want to start over? All your fun recipe ideas will be gone! 🥺')) {
      nameCount.textContent = '0';
      descCount.textContent = '0';
      fileNameDisplay.textContent = '';
      uploadArea.style.borderColor = '#FFDAC1';
      uploadArea.style.backgroundColor = '#FFFCF9';
      uploadArea.classList.remove('required-missing');

      urlInput.classList.remove('active');
      uploadInput.classList.remove('active');

      recipeForm.reset();

      // Remove any error messages
      const existingError = document.querySelector('.client-error-message');
      if (existingError) {
        existingError.remove();
      }

      setTimeout(function() {
        ingredientsContainer.innerHTML = `
          <div class="ingredient-row">
            <div class="form-group ingredient-name">
              <label>Ingredient Name <span class="required">*</span></label>
              <input type="text" name="ingredientName[]" placeholder="e.g., Banana 🍌" required>
            </div>
            <div class="form-group ingredient-amount">
              <label>Amount <span class="required">*</span></label>
              <input type="text" name="ingredientQuantity[]" placeholder="e.g., 1 medium" required>
            </div>
          </div>
        `;

        stepsContainer.innerHTML = `
          <div class="step-row">
            <div class="form-group step-number">
              <label>Step #<span class="step-counter">1</span></label>
              <input type="text" name="stepTitle[]" placeholder="Step title (optional)">
            </div>
            <div class="form-group step-content">
              <label>Step Description <span class="required">*</span></label>
              <textarea name="stepDescription[]" placeholder="Write step in a fun way for kids! 🎯" rows="2" required></textarea>
            </div>
            <div class="step-controls">
              <button type="button" class="remove-btn remove-step" style="display: none;">
                <i class="fas fa-trash"></i> Remove
              </button>
            </div>
          </div>
        `;

        ingredientCount = 1;
        stepCount = 1;
      }, 100);
    }
  });

  function setActive(element) {
    const links = document.querySelectorAll("nav a");
    links.forEach(link => link.classList.remove("active"));
    element.classList.add("active");
  }
</script>

</body>
</html>
